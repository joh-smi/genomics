import boto3
from PIL import Image
import io
import os

s3 = boto3.client('s3')
bucket_b = os.environ.get('BUCKET_B', 'gel-platform-bucket-b')

def lambda_handler(event, context):
    for record in event['Records']:
        bucket_a = record['s3']['bucket']['name']
        key = record['s3']['object']['key']

        obj = s3.get_object(Bucket=bucket_a, Key=key)
        img = Image.open(io.BytesIO(obj['Body'].read()))
        
        data = io.BytesIO()
        img.save(data, format="JPEG")
        data.seek(0)

        s3.put_object(Bucket=bucket_b, Key=key, Body=data, ContentType='image/jpeg')
        
    return {"status": "success"}

